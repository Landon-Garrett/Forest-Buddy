8" Wheel for 1/2" Square Axel by nick_shea on Thingiverse: https://www.thingiverse.com/thing:6901972

Summary:
If you have a seed spreader with 8" plastic wheels on a 1/2 square tube axel, you're in the right place. I recommend supports beneath the diameter of the inner hub. Supports beneath the "Tire" arc shouldn't be required. Should not need supports higher than 1/2" above your Build Surface.